# Quiz App

A simple quiz application built using Flask.

## Features
- Displays multiple-choice questions.
- Calculates and displays the score.

## Requirements
- Python 3.x
- Flask

## Setup
1. Install dependencies: `pip install flask`
2. Run the app: `python main.py`
3. Open `http://127.0.0.1:5000` in your browser.

Enjoy the quiz!